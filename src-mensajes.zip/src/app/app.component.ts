import { Component, NgModule } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { MensajesComponent } from './modulo/mensajes/mensajes.component';
import { ModuloModule } from './modulo/modulo.module';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,ModuloModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Ejemplo';
}
