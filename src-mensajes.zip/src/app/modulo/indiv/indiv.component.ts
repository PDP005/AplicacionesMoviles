import { Component } from '@angular/core';

@Component({
  selector: 'app-indiv',
  standalone: false,
  templateUrl: './indiv.component.html',
  styleUrl: './indiv.component.css'
})
export class IndivComponent {

}
