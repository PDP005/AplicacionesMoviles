import { NgModule } from '@angular/core';
import { CommonModule, NgFor, NgIf } from '@angular/common';
import { MensajesComponent } from './mensajes/mensajes.component';
import { RouterModule } from '@angular/router';



@NgModule({
  declarations: [MensajesComponent],
  imports: [
    CommonModule,RouterModule,NgFor,NgIf
  ],
  exports:[MensajesComponent]
})
export class ModuloModule { }
