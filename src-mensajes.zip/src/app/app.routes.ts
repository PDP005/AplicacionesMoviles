import { Routes } from '@angular/router';
import { MensajesComponent } from './modulo/mensajes/mensajes.component';

export const routes: Routes = [
    { path: 'mensajes', component: MensajesComponent },
    { path: '',redirectTo:'/mensajes',pathMatch: 'full'}
];
