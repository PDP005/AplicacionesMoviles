import { Routes } from '@angular/router';
import { InicioComponent } from './modulo/inicio/inicio.component';
import { VehiculosComponent } from './modulo/vehiculos/vehiculos.component';
import { DuenosComponent } from './modulo/duenos/duenos.component';

export const routes: Routes = [
    { path: 'inicio', component: InicioComponent },
    { path: '',redirectTo:'duenos',pathMatch: 'full'},
    { path: 'vehiculos', component: VehiculosComponent },
    { path: 'duenos', component: DuenosComponent },

];
