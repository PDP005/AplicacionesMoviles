import { Component } from '@angular/core';
import { IDueño } from '../IDueños';
import { ServicesService } from '../services/services.service';

@Component({
  selector: 'app-duenos',
  standalone: true,
  imports: [],
  templateUrl: './duenos.component.html',
  styleUrl: './duenos.component.css'
})
export class DuenosComponent {
  listaDuenos:IDueño[]=[]
  constructor(private data:ServicesService){}
  ngOnInit(){
    this.data.getDuenos().subscribe(
        array_datos => {
            array_datos.forEach(
                d => {
                    this.listaDuenos.push(d)
                }
            )
        }
    )
}
}
