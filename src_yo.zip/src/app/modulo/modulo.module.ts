import { NgModule } from '@angular/core';
import { CommonModule, NgFor, NgIf } from '@angular/common';
import { InicioComponent } from './inicio/inicio.component';
import { DuenosComponent } from './duenos/duenos.component';
import { VehiculosComponent } from './vehiculos/vehiculos.component';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { provideHttpClient, withFetch } from '@angular/common/http';



@NgModule({
  declarations: [InicioComponent,DuenosComponent,VehiculosComponent],
  imports: [
    CommonModule,RouterModule,FormsModule,NgFor
  ],
  exports:[InicioComponent,DuenosComponent,VehiculosComponent],
})
export class ModuloModule { }
