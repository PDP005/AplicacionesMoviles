import { Component } from '@angular/core';

@Component({
  selector: 'app-vehiculos',
  standalone: true,
  imports: [],
  templateUrl: './vehiculos.component.html',
  styleUrl: './vehiculos.component.css'
})
export class VehiculosComponent {

}
