import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IDueño } from '../IDueños';

@Injectable({
  providedIn: 'root'
})
export class ServicesService {

  constructor(private http: HttpClient) { }

  public getDuenos(): Observable<IDueño[]>{
    return this.http.get<IDueño[]>("/assets/data/dueños.json");
   }
}
