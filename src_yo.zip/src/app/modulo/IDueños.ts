export interface IDueño {
    id: number;
    name: string;
    age: number;
    vehicleId: number;
  }