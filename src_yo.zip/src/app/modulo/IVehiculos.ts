export interface IVehiculo {
    id: number;
    type: string;
    brand: string;
    model: string;
    year: number;
  }