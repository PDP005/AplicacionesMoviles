import { Component, NgModule } from '@angular/core';
import { RouterModule, ParamMap, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-individual',
  standalone: false,
  templateUrl: './individual.component.html',
  styleUrl: './individual.component.css'
})
export class IndividualComponent {
  id:string="";

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.id = params.get('id') || '';
    });
  }

}

