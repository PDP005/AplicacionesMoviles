import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterModule } from '@angular/router';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
    RouterModule,ActivatedRoute,NgModule
  ]
})
export class ModuloModule { }
