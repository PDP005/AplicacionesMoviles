import { Routes } from '@angular/router';
import { SeriesComponent } from './modulo/series/series.component';
import { PelisComponent } from './modulo/pelis/pelis.component';
import { TodoComponent } from './modulo/todo/todo.component';
import { IndividualComponent } from './modulo/individual/individual.component';

export const routes: Routes = [
        { path: '', component: TodoComponent },
        { path: 'series', component: SeriesComponent },
        { path: 'movies', component: PelisComponent },
        { path: 'individual/:id', component: IndividualComponent },];
