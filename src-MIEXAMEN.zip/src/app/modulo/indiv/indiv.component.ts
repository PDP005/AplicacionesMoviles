import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { ServicesService } from '../services/services.service';
import { IDueño } from '../IDueños';
import { IVehiculo } from '../IVehiculos';

@Component({
  selector: 'app-indiv',
  standalone: false,
  templateUrl: './indiv.component.html',
  styleUrl: './indiv.component.css'
})
export class IndivComponent {
  id:number=0;
  listaVehiculo:IVehiculo[]=[]
  constructor(private route: ActivatedRoute,private data:ServicesService) {
    this.data.getVehiculos().subscribe(
        array_datos => {
            array_datos.forEach(d => 
                {this.listaVehiculo.push(d)}
            )
        }
    )
      }
  ngOnInit(): void {
    this.route.paramMap.subscribe((params: ParamMap) => {
      //para sacar el id
      this.id = Number(params.get('id')) || 0;
    });

}
}
