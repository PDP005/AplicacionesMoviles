export interface IDatos{
  duenos:IDueño[];
}
export interface IDueño {
    id: number;
    name: string;
    age: number;
    vehicleId: number;
  }