import { Component } from '@angular/core';
import { IDatos, IDueño } from '../IDueños';
import { ServicesService } from '../services/services.service';

@Component({
  selector: 'app-duenos',
  standalone: false,
  
  templateUrl: './duenos.component.html',
  styleUrl: './duenos.component.css'
})
export class DuenosComponent {
  listaDuenos:IDueño[]=[]
  constructor(private data:ServicesService){}
  ngOnInit(){
    this.data.getDuenos().subscribe(
        //te devuelve todo y guarda el todo en get duenos
        array_datos => {
            array_datos.duenos.forEach(d => 
                {/*aqui puedo meter if */ this.listaDuenos.push(d)}
            )
        }
    )
}
}
