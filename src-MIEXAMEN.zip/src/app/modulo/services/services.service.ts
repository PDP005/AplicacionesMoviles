import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IDatos, IDueño } from '../IDueños';
import { IVehiculo } from '../IVehiculos';

@Injectable({
  providedIn: 'root'
})
export class ServicesService {

  constructor(private http: HttpClient) { }

  public getDuenos(): Observable<IDatos>{
    //array de datosimport { routes } from '../../app.routes';

    return this.http.get<IDatos>("data/duenos.json");
   }
   public getVehiculos(): Observable<IVehiculo[]>{
    return this.http.get<IVehiculo[]>("data/vehiculos.json");
   }
}
