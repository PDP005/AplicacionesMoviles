import { NgModule } from '@angular/core';
import { CommonModule, NgFor, NgIf } from '@angular/common';
import { InicioComponent } from './inicio/inicio.component';
import { DuenosComponent } from './duenos/duenos.component';
import { VehiculosComponent } from './vehiculos/vehiculos.component';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { IndivComponent } from './indiv/indiv.component';



@NgModule({
  declarations: [InicioComponent,DuenosComponent,VehiculosComponent,IndivComponent],
  imports: [
    CommonModule,RouterModule,FormsModule,
  ],
  exports:[InicioComponent,DuenosComponent,VehiculosComponent,IndivComponent],
})
export class ModuloModule { }
