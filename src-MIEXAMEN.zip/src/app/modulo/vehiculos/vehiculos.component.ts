import { Component } from '@angular/core';
import { IVehiculo } from '../IVehiculos';
import { ServicesService } from '../services/services.service';

@Component({
  selector: 'app-vehiculos',
  standalone: false,
  
  templateUrl: './vehiculos.component.html',
  styleUrl: './vehiculos.component.css'
})
export class VehiculosComponent {
  listaVehiculos:IVehiculo[]=[]
  constructor(private data:ServicesService){}
  ngOnInit(){
    this.data.getVehiculos().subscribe(
        array_datos => {
            array_datos.forEach(
                d => {
                    this.listaVehiculos.push(d)
                }
            )
        }
    )
}
}
