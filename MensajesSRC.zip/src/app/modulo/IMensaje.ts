export interface IMensaje{
    Id:number,
    Nombre:string,
    Asunto:string,
    Texto:string
}