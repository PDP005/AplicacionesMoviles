import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { PelisComponent } from './modulo/pelis/pelis.component';
import { SeriesComponent } from './modulo/series/series.component';
import { InicioComponent } from './modulo/inicio/inicio.component';
import { TodoComponent } from './modulo/todo/todo.component';
import { IndividualComponent } from './modulo/individual/individual.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,PelisComponent,SeriesComponent,InicioComponent,TodoComponent,IndividualComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})

export class AppComponent {
  title = 'Ejemplo';
}
