import { Component, NgModule } from '@angular/core';
import { RouterModule, ParamMap, ActivatedRoute } from '@angular/router';
import { Ipelis } from '../pelis/Peliculas';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-individual',
  standalone: true,
  imports:[CommonModule],
  templateUrl: './individual.component.html',
  styleUrl: './individual.component.css'
})
export class IndividualComponent {
  id:string="";

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.id = params.get('id') || '';
    });
  }
  peliculas:Ipelis[] = [
  
    {caratula:"assest/imagenes/Superman-js.jpg", titulo: 'si',director: 'si',ano: 200,sinopsis:'',puntuacion:0,id:"1"},
    {caratula:'', titulo: 'no',director: 'no',ano: 100,sinopsis:'',puntuacion:0,id:"2"},  
    {caratula:"assest/imagenes/Superman-js.jpg", titulo: 'si',director: 'si',ano: 200,sinopsis:'',puntuacion:0,id:"3"},
    {caratula:'', titulo: 'no',director: 'no',ano: 100,sinopsis:'',puntuacion:0,id:"4"},  
    {caratula:"assest/imagenes/Superman-js.jpg", titulo: 'si',director: 'si',ano: 200,sinopsis:'',puntuacion:0,id:"1"},
    {caratula:'', titulo: 'no',director: 'no',ano: 100,sinopsis:'',puntuacion:0,id:"1"},  
    {caratula:"assest/imagenes/Superman-js.jpg", titulo: 'si',director: 'si',ano: 200,sinopsis:'',puntuacion:0,id:"1"},
    {caratula:'', titulo: 'no',director: 'no',ano: 100,sinopsis:'',puntuacion:0,id:"1"},   
    
  ];
}

