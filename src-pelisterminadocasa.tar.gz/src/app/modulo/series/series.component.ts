import { Component } from '@angular/core';
import { Iseries } from './Series';
import { CommonModule, NgFor } from '@angular/common';

@Component({
  selector: 'app-series',
  standalone: true,
  imports:[CommonModule],
  templateUrl: './series.component.html',
  styleUrl: './series.component.css'
})
export class SeriesComponent {
  series:Iseries[] = [
    {caratula:"assest/imagenes/Superman-js.jpg", titulo: 'serie',director: 'si',temporadas: 200,sinopsis:'',plataforma:'Netflix'},
    {caratula:"assest/imagenes/Superman-js.jpg", titulo: 'serie',director: 'si',temporadas: 200,sinopsis:'',plataforma:'Netflix'},
    {caratula:"assest/imagenes/Superman-js.jpg", titulo: 'serie',director: 'si',temporadas: 200,sinopsis:'',plataforma:'Netflix'},
    {caratula:"assest/imagenes/Superman-js.jpg", titulo: 'serie',director: 'si',temporadas: 200,sinopsis:'',plataforma:'Netflix'},
    {caratula:"assest/imagenes/Superman-js.jpg", titulo: 'serie',director: 'si',temporadas: 200,sinopsis:'',plataforma:'Netflix'},
  ]
}
