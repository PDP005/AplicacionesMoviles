import { Component } from '@angular/core';
import { PelisComponent } from '../pelis/pelis.component';
import { SeriesComponent } from '../series/series.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-todo',
  standalone: true,
  imports:[CommonModule,PelisComponent,SeriesComponent],
  templateUrl: './todo.component.html',
  styleUrl: './todo.component.css'
})
export class TodoComponent {

}
