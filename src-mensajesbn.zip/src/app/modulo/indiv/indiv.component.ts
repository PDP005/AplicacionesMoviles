import { Component } from '@angular/core';
import { IMensaje } from '../IMensaje';
import { ServiciosService } from '../../servicios/servicios.service';
import { ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-indiv',
  standalone: false,
  templateUrl: './indiv.component.html',
  styleUrl: './indiv.component.css'
})
export class IndivComponent {
  listaMensajes:IMensaje[]=[]
  id:string=""
  constructor(private data:ServiciosService,private route:ActivatedRoute){}
  ngOnInit(){
    this.data.getMensajes().subscribe(
        array_datos => {
            array_datos.forEach(
                d => {
                    this.listaMensajes.push(d)
0                }
            )
        }
    )
    this.route.paramMap.subscribe((params: ParamMap) => {
        this.id = params.get('Id') || '';
      });    
}
}
