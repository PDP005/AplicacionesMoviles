import { Component } from '@angular/core';
import { IMensaje } from '../IMensaje';
import { ServiciosService } from '../../servicios/servicios.service';

@Component({
  selector: 'app-mensajes',
  standalone: false,
  templateUrl: './mensajes.component.html',
  styleUrl: './mensajes.component.css'
})
export class MensajesComponent {

  listaMensajes:IMensaje[]=[]
  constructor(private data:ServiciosService){}
  ngOnInit(){
    this.data.getMensajes().subscribe(
        array_datos => {
            array_datos.forEach(
                d => {
                    this.listaMensajes.push(d)
                }
            )
        }
    )
}
}
