export interface Ipelis{
    caratula:string;
    titulo:string;
    ano:number;
    director:string;
    sinopsis:string;
    puntuacion:number;
}