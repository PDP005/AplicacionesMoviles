import { Routes } from '@angular/router';
import { SeriesComponent } from './series/series.component';
import { PelisComponent } from './pelis/pelis.component';
import { TodoComponent } from './todo/todo.component';

export const routes: Routes = [
        { path: '', component: TodoComponent },
        { path: 'series', component: SeriesComponent },
        { path: 'movies', component: PelisComponent },
];
