export interface IAVisual {
    id?:number;
    titulo?: string;
    director?: string;
    anio?: number;
    plataforma?: string | null;
    imagen?: string;
    sinopsis?: string;
    puntuacion?: number;
    temporadas?: number;

  }