import { Injectable } from '@angular/core';
import { IAVisual } from '../componentes/IAVisual';

@Injectable({
  providedIn: 'root'
})
export class FilmService {

  private  l_multimedia:IAVisual[]=[]
  constructor() { 
      this.l_multimedia = [
      {
        id:1,
        titulo: 'El Padrino',
        director: 'Francis Ford Coppola',
        anio: 1972,
        plataforma:null,
        imagen: 'elPadrino.jpg',
        sinopsis:"Don Vito Corleone es el respetado y temido jefe de una de las cinco familias de la mafia de Nueva York en los años 40. El hombre tiene cuatro hijos: Connie, Sonny, Fredo y Michael, que no quiere saber nada de los negocios sucios de su padre. Cuando otro capo, Sollozzo, intenta asesinar a Corleone, empieza una cruenta lucha entre los distintos clanes.", 
        puntuacion: 9,
        temporadas:0
      },
      {
        id:2,
        titulo: 'El Señor de los Anillos: La Comunidad del Anillo',
        director: 'Peter Jackson', 
        anio: 2001, 
        plataforma:'Prime',
        imagen: 'elSeñorDeLosAnillos.jpg', 
        sinopsis:"En la Tierra Media, el Señor Oscuro Sauron forjó los Grandes Anillos del Poder y creó uno con el poder de esclavizar a toda la Tierra Media. Frodo Bolsón es un hobbit al que su tío Bilbo hace portador del poderoso Anillo Único con la misión de destruirlo. Acompañado de sus amigos, Frodo emprende un viaje hacia Mordor, el único lugar donde el anillo puede ser destruido. Sin embargo, Sauron ordena la persecución del grupo para recuperar el anillo y acabar con la Tierra Media.",
        puntuacion: 8 ,
        temporadas:3
        },
      {
        id:1, 
        titulo: 'Vikingos',
        director:'AA',
        anio:111,
        plataforma:"Netflix",
        imagen: 'vikingos.png',
        sinopsis:"El programa retrata a Ragnar como un granjero que ha conseguido construir barcos revolucionarios con instrumentos de navegación también revolucionarios. Con ellas puede hacer exitosas incursiones en Inglaterra, alcanzar la fama y convertirse en un rey escandinavo, con la ayuda de su familia y sus guerreros.",
        puntuacion:1,
        temporadas: 6,   
      },
      {
        id:1, 
        titulo: 'a',
        director:'a',
        anio:1,
        plataforma:"a",
        imagen: 'breaking-bad.png',
        sinopsis:"a",
        puntuacion:1,
        temporadas: 1,   
      },


    ];

  }
  public getAll():IAVisual[]{
    return this.l_multimedia;
  }
  public getPeliculas(): IAVisual[]{

    /*
    let aux:IAVisual[]=[];
    this.l_multimedia.forEach(item=>{if (item.temporadas==0) aux.push(item); })
    return aux;
    */

    return this.l_multimedia.filter(item=>item.temporadas==0);
  }
  public getSeries(): IAVisual[]{
    //recorre y por cada elemento y si tiene temp lo mete en un item temporal
    return this.l_multimedia.filter(item=>item.temporadas!=0);

  }

  public getPelicula(id:number):IAVisual {
    let pelicula:IAVisual={};
    this.l_multimedia.forEach(item=>{if (item.id=id) pelicula=item;})
    return pelicula;
    //return this.l_multimedia.find(item=>item.id==id)
  }
  public getSerie(id:number):IAVisual | undefined {
    return this.l_multimedia.find(item=>item.id==id)
  }



}
