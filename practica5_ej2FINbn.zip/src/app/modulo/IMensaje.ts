export interface IMensaje{
    Id:string,
    Nombre:string,
    Asunto:string,
    Texto:string
}