import { NgModule } from '@angular/core';
import { CommonModule, NgFor, NgIf } from '@angular/common';
import { MensajesComponent } from './mensajes/mensajes.component';
import { ActivatedRoute, RouterModule, ParamMap } from '@angular/router';
import { IndivComponent } from './indiv/indiv.component';



@NgModule({
  declarations: [MensajesComponent,IndivComponent],
  imports: [
    CommonModule,RouterModule,NgFor,NgIf
  ],
  exports:[MensajesComponent,IndivComponent]
})
export class ModuloModule { }
