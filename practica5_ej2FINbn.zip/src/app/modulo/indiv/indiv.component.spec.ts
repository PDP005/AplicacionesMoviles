import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IndivComponent } from './indiv.component';

describe('IndivComponent', () => {
  let component: IndivComponent;
  let fixture: ComponentFixture<IndivComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [IndivComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IndivComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
