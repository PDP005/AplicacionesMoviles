export interface Iseries{
    caratula:string;
    titulo:string;
    temporadas:number;
    director:string;
    sinopsis:string;
    plataforma:string;
}